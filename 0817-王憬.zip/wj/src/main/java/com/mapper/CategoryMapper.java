package com.mapper;

import com.entity.Category;

import java.util.List;

/**
 * @author :muxiaowen
 * @date : 2022/8/17 9:04
 */
public interface CategoryMapper {
    List<Category> categoryList();
}
